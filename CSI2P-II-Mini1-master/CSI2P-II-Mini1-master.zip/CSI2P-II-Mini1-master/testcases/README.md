# Testcases

## Submission

We provide 5 basic testcases.

You can verify your code through <https://acm.cs.nthu.edu.tw/contest/1428/>.

Please submit whole code in ***main.c*** to OJ.

## Judging System

We judge your solution by the special judge on OJ. Your assembly code might differ, so we evaluate your solutions by passing it to the written parser. The parser will generate 3 corresponding results (x, y, z from 3 reg space), and we will judge your solutions based on these three values