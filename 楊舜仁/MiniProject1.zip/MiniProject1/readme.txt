﻿1. "Mini project 1.pptx" 是mini project1 的介紹。

2. "MiniProject1_loop" 和 "MiniProject1_recursion" 是我們提供的package.請參考 "Mini-Project 1 - package 解說.pptx"

3.完成project 後, 可以使用 "miniproject parser" 測試.測資在 "parser test case".

4.請同學注意:"parser test case"裡的測資中，x、y、z的初始值皆為0，但demo時並不會初始為0，同學必須自己去找出.可以參考"Mini project 1.pptx"投影片的第5頁.

5.記憶體不會發生超過 256 bytes 的錯誤.
