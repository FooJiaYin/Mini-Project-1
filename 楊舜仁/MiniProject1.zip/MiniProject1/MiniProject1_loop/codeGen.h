#include "parser.h"
#ifndef __CODEGEN__
#define __CODEGEN__

extern int evaluateTree(BTNode *root);
extern void printPrefix(BTNode *root);

#endif // __CODEGEN__
